import express from "express";
import path from "path";
import cors from "cors";
import helmet from "helmet";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(cors());

// Helmet configuration that plays nice with Vite's client in dev and production
app.use(
  helmet({
    contentSecurityPolicy: false, // Turn off CSP to let iframe and local resources render freely
    crossOriginEmbedderPolicy: false,
  })
);

// In-memory databases
const messages = [
  {
    id: "1",
    name: "Aida Bot",
    email: "aida@example.com",
    message: "System fully initialized! Ready to test your portfolio and submit custom feedback.",
    createdAt: new Date().toISOString(),
  },
];

const projects = [
  {
    id: "tastebuds",
    title: "Tastebuds",
    tags: ["Node.js", "Express.js", "PostgreSQL", "Gemini API"],
    description: "An intelligent meal-planning platform leveraging AI-driven recipe generation with dynamic filtering for dietary preferences.",
    bullets: [
      "Engineered RESTful API backend",
      "Integrated Gemini API prompt engineering",
      "Automated meal-plan generation scripts"
    ],
    codeUrl: "https://github.com/sumeetkl11/tastebuds",
    liveUrl: "#tastebuds-demo"
  },
  {
    id: "socialconnect",
    title: "SocialConnect",
    tags: ["WebSockets", "Node.js", "Express.js", "PostgreSQL", "JavaScript"],
    description: "Designed the real-time messaging architecture and backend database schema for a modern social platform.",
    bullets: [
      "Scalable WebSocket servers",
      "Relational database architecture",
      "Cross-origin authorization"
    ],
    codeUrl: "https://github.com/sumeetkl11/socialconnect",
    liveUrl: "#socialconnect-demo"
  },
  {
    id: "linkforge",
    title: "Linkforge",
    tags: ["React.js", "Node.js", "Express.js", "Tailwind CSS"],
    description: "A streamlined full-stack utility tool built to manage and optimize digital links.",
    bullets: [
      "Fast redirection mechanics",
      "Semantic code",
      "Responsive interfaces"
    ],
    codeUrl: "https://github.com/sumeetkl11/linkforge",
    liveUrl: "#linkforge-demo"
  }
];

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// GET all projects
app.get("/api/projects", (req, res) => {
  res.json(projects);
});

// GET contact messages
app.get("/api/contact", (req, res) => {
  res.json(messages);
});

// POST contact message
app.post("/api/contact", (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ error: "All fields are required." });
  }
  const newMessage = {
    id: String(messages.length + 1),
    name,
    email,
    message,
    createdAt: new Date().toISOString(),
  };
  messages.push(newMessage);
  res.status(201).json({ success: true, message: "Message received successfully!", data: newMessage });
});

// POST generate recipe (Tastebuds AI Proxy)
app.post("/api/tastebuds/generate-recipe", async (req, res) => {
  try {
    const { diet_type, excluded_ingredients, meals_per_day, caloric_target } = req.body;

    const dietType = diet_type || "balanced";
    const excluded = excluded_ingredients && excluded_ingredients.length > 0 
      ? excluded_ingredients.join(", ") 
      : "none";
    const mealsCount = meals_per_day || 3;
    const calories = caloric_target || 2000;

    const prompt = `Generate a high-quality full day meal plan for a person following a ${dietType} diet.
    They absolutely cannot eat: ${excluded}.
    Create exactly ${mealsCount} meals (e.g. Breakfast, Lunch, Dinner, Snack if applicable) that sum up to approximately ${calories} calories.
    For each meal, provide the meal type, name of the meal, precise list of ingredients with measurements, step-by-step preparation instructions, and estimated macros (protein, carbs, fat in grams).`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are a professional nutritionist and gourmet chef who designs accurate, healthy, and realistic recipe meals.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            total_calories: { type: Type.INTEGER, description: "Total combined calories for the full meal plan." },
            meals: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  type: { type: Type.STRING, description: "Meal type, e.g., Breakfast, Lunch, Dinner, Snack" },
                  name: { type: Type.STRING, description: "The beautiful name of the dish." },
                  ingredients: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: "Ingredients and exact measurements."
                  },
                  instructions: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: "Step-by-step cooking instructions."
                  },
                  macros: {
                    type: Type.OBJECT,
                    properties: {
                      protein: { type: Type.STRING, description: "Protein in grams, e.g., 25g" },
                      carbs: { type: Type.STRING, description: "Carbs in grams, e.g., 40g" },
                      fat: { type: Type.STRING, description: "Fat in grams, e.g., 12g" }
                    },
                    required: ["protein", "carbs", "fat"]
                  }
                },
                required: ["type", "name", "ingredients", "instructions", "macros"]
              }
            }
          },
          required: ["total_calories", "meals"]
        }
      }
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error("No response content from Gemini API.");
    }

    const mealPlan = JSON.parse(resultText);
    res.json({ success: true, data: mealPlan });
  } catch (error: any) {
    console.error("Gemini Generation Error:", error);
    res.status(500).json({ error: "Failed to generate meal plan. " + (error.message || "") });
  }
});

// Vite & Static file serving middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT} (http://localhost:${PORT})`);
  });
}

startServer();
