import BackgroundCanvas from "./components/BackgroundCanvas";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Projects from "./components/Projects";
import Experience from "./components/Experience";
import TerminalContact from "./components/TerminalContact";
import { Terminal } from "lucide-react";

export default function App() {
  return (
    <div className="relative min-h-screen text-on-background font-sans selection:bg-blue-500/30 selection:text-blue-200">
      {/* 1. Immersive 3D Interactive background */}
      <BackgroundCanvas />

      {/* 2. Fixed top Navbar */}
      <Navbar />

      {/* 3. Main portfolio layers */}
      <main className="relative flex flex-col pt-[80px]">
        
        {/* Hero Landing */}
        <Hero />

        {/* Dynamic Project Showcases */}
        <Projects />

        {/* Experience Trajectory timeline */}
        <Experience />

        {/* Interactive CLI terminal / form contact */}
        <TerminalContact />

      </main>

      {/* 4. Brand Footer */}
      <footer className="w-full py-12 bg-[#0e0e0f]/90 backdrop-blur-md border-t border-white/5 relative z-10">
        <div className="max-w-[1200px] mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          
          {/* Logo */}
          <div className="flex items-center gap-2">
            <Terminal className="w-4.5 h-4.5 text-blue-400" />
            <span className="font-sans font-bold tracking-tight text-white text-sm">
              The Digital Nexus
            </span>
          </div>

          {/* Copy statement */}
          <p className="font-sans text-xs text-gray-500 text-center md:text-left">
            © 2026 The Digital Nexus. Engineered by Sumeet Kanhiya. Built in AI Studio.
          </p>

          {/* Socials quick anchors */}
          <div className="flex items-center gap-6">
            <a
              href="https://github.com/sumeetkl11"
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono text-[10px] text-gray-500 hover:text-blue-400 transition-colors uppercase tracking-widest"
            >
              GitHub
            </a>
            <span className="text-gray-700 select-none">|</span>
            <span className="font-mono text-[10px] text-gray-500 cursor-default uppercase tracking-widest">
              LinkedIn
            </span>
          </div>

        </div>
      </footer>
    </div>
  );
}
