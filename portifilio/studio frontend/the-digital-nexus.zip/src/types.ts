export interface Macros {
  protein: string;
  carbs: string;
  fat: string;
}

export interface Meal {
  type: string;
  name: string;
  ingredients: string[];
  instructions: string[];
  macros: Macros;
}

export interface MealPlan {
  total_calories: number;
  meals: Meal[];
}

export interface Project {
  id: string;
  title: string;
  tags: string[];
  description: string;
  bullets: string[];
  codeUrl: string;
  liveUrl: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  message: string;
  createdAt: string;
}
