import React, { useState, useEffect, useRef } from "react";
import { Terminal as TermIcon, Mail, Github, Linkedin, Twitter, AlertTriangle, CheckCircle2, ChevronRight, Play } from "lucide-react";
import { ContactMessage } from "../types";

export default function TerminalContact() {
  const [useTerminalMode, setUseTerminalMode] = useState(false);
  
  // Standard Form States
  const [formName, setFormName] = useState("");
  const [formEmail, setFormEmail] = useState("");
  const [formMessage, setFormMessage] = useState("");
  const [formLoading, setFormLoading] = useState(false);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  // Command Line States
  const [commandInput, setCommandInput] = useState("");
  const [terminalHistory, setTerminalHistory] = useState<string[]>([
    "The Digital Nexus Terminal [Version 1.0.0]",
    "System Node secure-proxy-session successfully established.",
    "Type 'help' to view all system commands, or toggle GUI form mode.",
    "",
  ]);

  const [recentMessages, setRecentMessages] = useState<ContactMessage[]>([]);
  const terminalBottomRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll terminal history to bottom
  useEffect(() => {
    if (terminalBottomRef.current) {
      terminalBottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [terminalHistory]);

  // Fetch recent messages on mount to show other visitor feedback
  const fetchRecentMessages = async () => {
    try {
      const response = await fetch("/api/contact");
      if (response.ok) {
        const data = await response.json();
        setRecentMessages(data);
      }
    } catch (err) {
      console.error("Failed to load terminal logs", err);
    }
  };

  useEffect(() => {
    fetchRecentMessages();
  }, []);

  // Submit standard contact form
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formEmail.trim() || !formMessage.trim()) {
      setFormError("All fields are required.");
      return;
    }

    setFormLoading(true);
    setFormError(null);
    setFormSuccess(null);

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formName,
          email: formEmail,
          message: formMessage,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to submit message.");
      }

      setFormSuccess("Secure connection established. Message successfully logged to PostgreSQL!");
      setFormName("");
      setFormEmail("");
      setFormMessage("");
      fetchRecentMessages(); // Refresh message log feed
    } catch (err: any) {
      setFormError(err.message || "Network socket drop occurred.");
    } finally {
      setFormLoading(false);
    }
  };

  // Submit terminal command line
  const handleCommandSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const command = commandInput.trim();
    if (!command) return;

    // Add command to history
    setTerminalHistory((prev) => [...prev, `sumeet@nexus:~$ ${command}`]);
    setCommandInput("");

    const parts = command.match(/(?:[^\s"]+|"[^"]*")+/g) || [];
    const baseCommand = parts[0]?.toLowerCase();

    switch (baseCommand) {
      case "help":
        setTerminalHistory((prev) => [
          ...prev,
          "Available system-level utilities:",
          "  help                             Display this information menu.",
          "  about                            Print developer credentials & bio.",
          "  skills                           List tech stack and proficiencies.",
          "  messages                         Query database for guestbook entries.",
          "  clear                            Flush terminal buffer.",
          "  contact \"<name>\" \"<email>\" \"<msg>\"   Direct form submission utility.",
          "",
        ]);
        break;

      case "about":
        setTerminalHistory((prev) => [
          ...prev,
          "Candidate: Sumeet Kanhiya",
          "Role: Full Stack Engineer (PERN Stack Specialist)",
          "Mission: Building ultra-scalable, mathematically consistent backends and highly visual responsive user layouts.",
          "Status: Active and seeking freelance or contract opportunities.",
          "",
        ]);
        break;

      case "skills":
        setTerminalHistory((prev) => [
          ...prev,
          "Sumeet's Core Competencies:",
          "  - Backend: Node.js, Express.js, TypeScript, RESTful APIs, WebSockets",
          "  - Database: PostgreSQL, Prisma, SQL Optimization, Connection Pooling",
          "  - Frontend: React.js, Tailwind CSS, Motion, HTML5 Canvas 3D",
          "  - AI Integrations: Gemini API Prompt Tuning, Proxy Orchestrations",
          "",
        ]);
        break;

      case "clear":
        setTerminalHistory([]);
        break;

      case "messages":
        setTerminalHistory((prev) => [...prev, "Querying message relational logs from PostgreSQL..."]);
        try {
          const res = await fetch("/api/contact");
          if (res.ok) {
            const data: ContactMessage[] = await res.json();
            setTerminalHistory((prev) => [
              ...prev,
              `Successfully retrieved ${data.length} database logs:`,
              ...data.map((msg) => `  [${new Date(msg.createdAt).toLocaleDateString()}] ${msg.name} (${msg.email}): "${msg.message}"`),
              "",
            ]);
          } else {
            setTerminalHistory((prev) => [...prev, "  Error: Server database rejected the query.", ""]);
          }
        } catch {
          setTerminalHistory((prev) => [...prev, "  Error: Socket failure querying postgres.js backend.", ""]);
        }
        break;

      case "contact":
        if (parts.length < 4) {
          setTerminalHistory((prev) => [
            ...prev,
            "  Error: Missing arguments.",
            "  Usage: contact \"Your Name\" \"your@email.com\" \"your message here\"",
            "",
          ]);
          break;
        }

        const name = parts[1].replace(/"/g, "");
        const email = parts[2].replace(/"/g, "");
        const msg = parts[3].replace(/"/g, "");

        setTerminalHistory((prev) => [...prev, `  Initiating post request to /api/contact for ${name}...`]);

        try {
          const response = await fetch("/api/contact", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, message: msg }),
          });
          const resData = await response.json();
          if (response.ok) {
            setTerminalHistory((prev) => [
              ...prev,
              "  [Success] Transaction committed to PG database.",
              `  [Success] Recorded feedback row ID: ${resData.data.id}`,
              "",
            ]);
            fetchRecentMessages();
          } else {
            setTerminalHistory((prev) => [...prev, `  [Error] Database rejected row: ${resData.error}`, ""]);
          }
        } catch {
          setTerminalHistory((prev) => [...prev, "  [Error] Secure pipeline dropped connection.", ""]);
        }
        break;

      default:
        setTerminalHistory((prev) => [
          ...prev,
          `  Command '${command}' unrecognized by shell. Type 'help' to review guidelines.`,
          "",
        ]);
        break;
    }
  };

  return (
    <section id="contact" className="py-24 px-6 relative z-10 max-w-[1200px] mx-auto">
      {/* Background radial highlight */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-blue-500/5 blur-[100px] rounded-full pointer-events-none" />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        {/* Left Bio and Socials column */}
        <div className="lg:col-span-5 flex flex-col gap-6 text-left">
          <span className="font-mono text-xs text-blue-400 font-semibold px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 uppercase tracking-widest inline-block mr-auto">
            Gateway Portal
          </span>
          <h2 className="font-sans font-extrabold text-4xl md:text-5xl text-white tracking-tight leading-none mb-2">
            Let's Build Something Scalable.
          </h2>
          <p className="font-sans text-gray-300 text-sm leading-relaxed mb-4">
            Currently open for new contract arrangements, freelance requests, and interesting systems engineering collaborations. Whether you have a specific database bottleneck or want to draft a complete AI application, feel free to submit feedback below.
          </p>

          {/* Social Links buttons with active click feedbacks */}
          <div className="flex flex-col gap-3">
            <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">Global Communication Hooks</span>
            
            <a
              href="mailto:sumeetkanhiya11@gmail.com"
              className="flex items-center gap-3 p-3 bg-white/[0.02] hover:bg-blue-500/10 border border-white/5 hover:border-blue-500/30 text-gray-300 hover:text-white rounded-lg transition-all duration-300 group cursor-pointer active:scale-95 shadow-md"
            >
              <div className="p-2 rounded-md bg-white/5 group-hover:bg-blue-500/20 text-gray-400 group-hover:text-blue-400 transition-colors">
                <Mail className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] font-mono text-gray-400 uppercase">Primary Email</span>
                <span className="text-xs font-mono font-bold select-all">sumeetkanhiya11@gmail.com</span>
              </div>
            </a>

            <a
              href="https://github.com/sumeetkl11"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 bg-white/[0.02] hover:bg-purple-500/10 border border-white/5 hover:border-purple-500/30 text-gray-300 hover:text-white rounded-lg transition-all duration-300 group cursor-pointer active:scale-95 shadow-md"
            >
              <div className="p-2 rounded-md bg-white/5 group-hover:bg-purple-500/20 text-gray-400 group-hover:text-purple-400 transition-colors">
                <Github className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] font-mono text-gray-400 uppercase">Open-Source Log</span>
                <span className="text-xs font-mono font-bold select-all">github.com/sumeetkl11</span>
              </div>
            </a>

            <div
              className="flex items-center gap-3 p-3 bg-white/[0.02] hover:bg-blue-500/10 border border-white/5 hover:border-blue-500/30 text-gray-300 hover:text-white rounded-lg transition-all duration-300 group cursor-default shadow-md"
            >
              <div className="p-2 rounded-md bg-white/5 group-hover:bg-blue-500/20 text-gray-400 group-hover:text-blue-400 transition-colors">
                <Linkedin className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] font-mono text-gray-400 uppercase">Professional Network</span>
                <span className="text-xs font-mono font-bold">LinkedIn Active Profile</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Terminal Contact Form column */}
        <div className="lg:col-span-7 w-full">
          <div className="bg-[#0e0e0f] rounded-2xl border border-white/10 overflow-hidden shadow-2xl flex flex-col h-[520px]">
            
            {/* Terminal Window Header Bar */}
            <div className="bg-white/[0.02] px-4 py-3 border-b border-white/10 flex justify-between items-center select-none">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500/75" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/75" />
                <div className="w-3 h-3 rounded-full bg-green-500/75" />
                <span className="font-mono text-xs text-gray-400 ml-2">
                  {useTerminalMode ? "bash -- session-terminal-log" : "gui_form_gateway.exe"}
                </span>
              </div>

              {/* Mode Toggler */}
              <button
                onClick={() => setUseTerminalMode(!useTerminalMode)}
                className="font-mono text-[10px] text-blue-400 hover:text-blue-300 bg-blue-500/10 hover:bg-blue-500/15 border border-blue-500/20 px-2.5 py-1 rounded transition-colors flex items-center gap-1 cursor-pointer"
              >
                <TermIcon className="w-3.5 h-3.5" />
                <span>{useTerminalMode ? "Switch to Form Mode" : "Switch to Command-Line"}</span>
              </button>
            </div>

            {/* Standard GUI Form Body */}
            {!useTerminalMode && (
              <div className="flex-grow p-6 md:p-8 flex flex-col justify-between">
                <form onSubmit={handleFormSubmit} className="flex flex-col gap-4">
                  {/* Name field */}
                  <div className="flex flex-col gap-1.5 text-left">
                    <label className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">
                      Operator Identity (Name)
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. John Doe"
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      className="bg-[#050505] border border-white/10 rounded-lg px-4 py-3 text-xs text-white focus:outline-none focus:border-blue-500 transition-all focus:shadow-[0_0_10px_rgba(59,130,246,0.15)]"
                    />
                  </div>

                  {/* Email field */}
                  <div className="flex flex-col gap-1.5 text-left">
                    <label className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">
                      Routing Socket Address (Email)
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. john@example.com"
                      value={formEmail}
                      onChange={(e) => setFormEmail(e.target.value)}
                      className="bg-[#050505] border border-white/10 rounded-lg px-4 py-3 text-xs text-white focus:outline-none focus:border-blue-500 transition-all focus:shadow-[0_0_10px_rgba(59,130,246,0.15)]"
                    />
                  </div>

                  {/* Message field */}
                  <div className="flex flex-col gap-1.5 text-left">
                    <label className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">
                      Payload Message Content
                    </label>
                    <textarea
                      required
                      rows={4}
                      placeholder="Type your message description here..."
                      value={formMessage}
                      onChange={(e) => setFormMessage(e.target.value)}
                      className="bg-[#050505] border border-white/10 rounded-lg px-4 py-3 text-xs text-white focus:outline-none focus:border-blue-500 transition-all focus:shadow-[0_0_10px_rgba(59,130,246,0.15)] resize-none"
                    />
                  </div>

                  {/* Submit status boxes */}
                  {formSuccess && (
                    <div className="p-3 bg-green-500/5 border border-green-500/15 rounded-lg flex items-center gap-2.5 text-green-400 text-xs text-left">
                      <CheckCircle2 className="w-4.5 h-4.5 flex-shrink-0" />
                      <span>{formSuccess}</span>
                    </div>
                  )}

                  {formError && (
                    <div className="p-3 bg-red-500/5 border border-red-500/15 rounded-lg flex items-center gap-2.5 text-red-400 text-xs text-left">
                      <AlertTriangle className="w-4.5 h-4.5 flex-shrink-0" />
                      <span>{formError}</span>
                    </div>
                  )}

                  {/* Form trigger button */}
                  <button
                    type="submit"
                    disabled={formLoading}
                    className={`w-full py-3 rounded-lg font-mono text-xs uppercase tracking-wider font-semibold transition-all ${
                      formLoading
                        ? "bg-blue-500/10 border border-blue-500/20 text-blue-400 cursor-not-allowed"
                        : "bg-blue-500 hover:bg-blue-600 text-white hover:shadow-[0_0_15px_rgba(59,130,246,0.4)] active:scale-95 cursor-pointer"
                    }`}
                  >
                    {formLoading ? "Transmitting..." : "Transmit Payload Message"}
                  </button>
                </form>

                {/* Live DB logs strip */}
                <div className="text-left mt-4 border-t border-white/5 pt-4 flex items-center gap-3 justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-ping" />
                    <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Live Visitor Feed</span>
                  </div>
                  {recentMessages.length > 0 && (
                    <div className="font-mono text-[9px] text-gray-400 truncate max-w-[280px]">
                      Latest row: {recentMessages[recentMessages.length - 1].name} ({recentMessages[recentMessages.length - 1].email})
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Simulated Interactive CLI terminal */}
            {useTerminalMode && (
              <div className="flex-grow p-4 md:p-6 font-mono text-xs flex flex-col justify-between overflow-hidden bg-[#050505]">
                {/* Terminal outputs history list */}
                <div className="flex-grow overflow-y-auto flex flex-col gap-1.5 pr-2 select-text text-left">
                  {terminalHistory.map((line, idx) => (
                    <div
                      key={idx}
                      className={`leading-relaxed whitespace-pre-wrap ${
                        line.startsWith("sumeet@nexus:~$")
                          ? "text-blue-400 font-semibold"
                          : line.startsWith("  [Success]") || line.startsWith("Successfully")
                          ? "text-green-400"
                          : line.startsWith("  [Error]") || line.startsWith("  Error:")
                          ? "text-red-400"
                          : "text-gray-300"
                      }`}
                    >
                      {line}
                    </div>
                  ))}
                  <div ref={terminalBottomRef} />
                </div>

                {/* Command Line Prompt Form */}
                <form onSubmit={handleCommandSubmit} className="border-t border-white/10 pt-3 flex items-center gap-2 mt-2">
                  <span className="text-blue-400 font-bold select-none">sumeet@nexus:~$</span>
                  <input
                    type="text"
                    required
                    autoFocus
                    placeholder="Type a command (e.g. 'help', 'skills', 'messages')..."
                    value={commandInput}
                    onChange={(e) => setCommandInput(e.target.value)}
                    className="flex-grow bg-transparent border-none text-white focus:outline-none placeholder-gray-600 font-mono"
                  />
                  <button type="submit" className="text-[10px] bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 px-2.5 py-1 text-gray-400 hover:text-white rounded cursor-pointer transition-colors">
                    Execute
                  </button>
                </form>
              </div>
            )}

          </div>
        </div>
      </div>
    </section>
  );
}
