import { Calendar, Briefcase, GraduationCap } from "lucide-react";

export default function Experience() {
  const experiences = [
    {
      period: "Dec 2024 - Present",
      title: "Freelance Web Developer",
      organization: "Independent Clients",
      description: "Engineered robust web applications and backend proxies. Audited site performance, optimized SQL data layers, and integrated responsive React and Vue frontends with Express API routing.",
      icon: Briefcase,
      color: "border-blue-500 text-blue-400 bg-blue-500/10",
    },
    {
      period: "Mar 2025 - Jun 2025",
      title: "Backend Developer @ Tastebuds AI",
      organization: "Tastebuds AI Initiative",
      description: "Architected core Node.js server pipelines, reduced external API request latencies by 35% using lazy loading/pooling, and implemented secure JSON schema validation routines using LLM engines.",
      icon: Briefcase,
      color: "border-purple-500 text-purple-400 bg-purple-500/10",
    },
    {
      period: "Expected Dec 2028",
      title: "B.S. Computer Science",
      organization: "Dawood University of Engineering and Technology (DUET)",
      description: "Academic focus on Database Management Systems (DBMS), Systems Programming, Software Engineering Methodologies, and Algorithmic Data Structures.",
      icon: GraduationCap,
      color: "border-gray-500 text-gray-300 bg-white/5",
      isDashed: true,
    },
  ];

  return (
    <section id="experience" className="py-24 px-6 relative z-10 bg-[#131314]/30">
      {/* Background glow blob */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-purple-500/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-[1200px] mx-auto">
        {/* Title */}
        <div className="mb-16 text-center">
          <span className="font-mono text-xs text-purple-400 font-semibold px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 uppercase tracking-widest inline-block mb-3">
            Career History
          </span>
          <h2 className="font-sans font-extrabold text-4xl md:text-5xl text-white tracking-tight leading-none mb-3">
            Experience Trajectory
          </h2>
          <p className="font-sans text-gray-400 text-base max-w-xl mx-auto">
            A linear progression of systems engineering, full-stack programming roles, and academic foundations.
          </p>
        </div>

        {/* Timeline Path */}
        <div className="relative max-w-3xl mx-auto pl-6 md:pl-0">
          
          {/* Vertical core line */}
          <div className="absolute left-6 md:left-1/2 top-0 bottom-0 w-[1px] bg-gradient-to-b from-blue-500 via-purple-500 to-transparent md:-translate-x-1/2" />

          {/* Nodes */}
          <div className="flex flex-col gap-12">
            {experiences.map((exp, idx) => {
              const Icon = exp.icon;
              const isEven = idx % 2 === 0;

              return (
                <div
                  key={idx}
                  className={`relative flex flex-col md:flex-row items-stretch md:justify-between w-full ${
                    isEven ? "md:flex-row-reverse" : ""
                  }`}
                >
                  {/* Outer circle dot */}
                  <div className="absolute left-[17px] md:left-1/2 top-4 w-4 h-4 rounded-full border-2 border-[#131314] bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.8)] md:-translate-x-1/2 z-10" />

                  {/* Empty spacing box for desktop grids */}
                  <div className="hidden md:block w-[45%]" />

                  {/* Main Content card */}
                  <div
                    className={`w-full md:w-[45%] p-6 rounded-2xl bg-[#1c1b1c]/30 backdrop-blur-md border ${
                      exp.isDashed ? "border-dashed border-white/10" : "border-white/10"
                    } hover:border-white/20 transition-all duration-300 relative group`}
                  >
                    {/* Timeframe label */}
                    <div className="flex items-center gap-2 mb-3">
                      <span className="p-1 rounded bg-white/5 border border-white/10">
                        <Calendar className="w-3.5 h-3.5 text-blue-400" />
                      </span>
                      <span className="font-mono text-xs font-semibold text-blue-400">
                        {exp.period}
                      </span>
                    </div>

                    {/* Job Details */}
                    <h4 className="font-sans font-bold text-lg text-white mb-1 group-hover:text-blue-300 transition-colors">
                      {exp.title}
                    </h4>
                    <span className="font-sans text-sm font-medium text-gray-400 block mb-3">
                      {exp.organization}
                    </span>
                    <p className="font-sans text-xs text-gray-300 leading-relaxed">
                      {exp.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </div>
    </section>
  );
}
