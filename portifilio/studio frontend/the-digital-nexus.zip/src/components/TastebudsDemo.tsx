import React, { useState } from "react";
import { MealPlan, Meal } from "../types";
import { Sparkles, Utensils, AlertCircle, Plus, X, ChevronRight, Calculator, RefreshCw } from "lucide-react";

export default function TastebudsDemo() {
  const [dietType, setDietType] = useState("balanced");
  const [excluded, setExcluded] = useState<string[]>([]);
  const [newExclusion, setNewExclusion] = useState("");
  const [mealsPerDay, setMealsPerDay] = useState(3);
  const [caloricTarget, setCaloricTarget] = useState(2000);

  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [mealPlan, setMealPlan] = useState<MealPlan | null>(null);

  const handleAddExclusion = (e: React.FormEvent) => {
    e.preventDefault();
    if (newExclusion.trim() && !excluded.includes(newExclusion.trim().toLowerCase())) {
      setExcluded([...excluded, newExclusion.trim().toLowerCase()]);
      setNewExclusion("");
    }
  };

  const handleRemoveExclusion = (ing: string) => {
    setExcluded(excluded.filter((x) => x !== ing));
  };

  const generateMealPlan = async () => {
    setLoading(true);
    setError(null);
    setMealPlan(null);

    // Custom steps to make loading state feel incredibly smart and professional
    const steps = [
      "Initializing secure server API request...",
      "Configuring Gemini-3.5-Flash model...",
      "Injecting prompt engineering templates...",
      "Analyzing dietary restrictions and excluded ingredients...",
      "Processing AI generation of gourmet meal plan...",
      "Validating output against strict JSON macro schemas...",
      "Sanitizing recipe objects and finishing up..."
    ];

    let currentStep = 0;
    setLoadingStep(steps[0]);

    const stepInterval = setInterval(() => {
      if (currentStep < steps.length - 1) {
        currentStep++;
        setLoadingStep(steps[currentStep]);
      }
    }, 1200);

    try {
      const response = await fetch("/api/tastebuds/generate-recipe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          diet_type: dietType,
          excluded_ingredients: excluded,
          meals_per_day: mealsPerDay,
          caloric_target: caloricTarget,
        }),
      });

      const data = await response.json();
      clearInterval(stepInterval);

      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to generate your meal plan. Please check server connections.");
      }

      setMealPlan(data.data);
    } catch (err: any) {
      clearInterval(stepInterval);
      setError(err.message || "An unexpected network error occurred.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full bg-[#1c1b1c]/40 backdrop-blur-md rounded-2xl border border-white/10 overflow-hidden shadow-2xl p-6 md:p-8">
      {/* Title block */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-white/10 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 bg-blue-500/10 border border-blue-500/20 text-blue-400 font-mono text-[10px] rounded-full uppercase tracking-wider">
              AI App Showcase
            </span>
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="font-mono text-[10px] text-gray-400">Live Backend Connected</span>
          </div>
          <h4 className="font-sans font-bold text-2xl text-white">Tastebuds AI Recipe Planner</h4>
          <p className="text-sm text-gray-400 max-w-xl">
            Input your nutritional metrics and dietary rules. Our backend proxies your constraints directly to Gemini, returning a perfectly structured gourmet meal plan.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl">
            <Utensils className="w-6 h-6 text-blue-400" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Control Column */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          {/* Diet Selection */}
          <div className="flex flex-col gap-2">
            <label className="font-sans font-semibold text-sm text-gray-200">Diet Type</label>
            <select
              value={dietType}
              onChange={(e) => setDietType(e.target.value)}
              className="bg-[#0e0e0f] border border-white/10 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors cursor-pointer"
            >
              <option value="balanced">Balanced / Any</option>
              <option value="high-protein">High-Protein</option>
              <option value="vegan">Vegan</option>
              <option value="keto">Keto (Low-Carb)</option>
              <option value="vegetarian">Vegetarian</option>
              <option value="paleo">Paleo</option>
            </select>
          </div>

          {/* Caloric Slider */}
          <div className="flex flex-col gap-2">
            <div className="flex justify-between items-center">
              <label className="font-sans font-semibold text-sm text-gray-200">Daily Calories</label>
              <span className="font-mono text-xs text-blue-400 font-semibold bg-blue-500/10 px-2 py-0.5 rounded">
                {caloricTarget} kcal
              </span>
            </div>
            <input
              type="range"
              min="1200"
              max="4500"
              step="100"
              value={caloricTarget}
              onChange={(e) => setCaloricTarget(Number(e.target.value))}
              className="w-full accent-blue-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-gray-500 font-mono">
              <span>1200 kcal</span>
              <span>4500 kcal</span>
            </div>
          </div>

          {/* Meals Per Day */}
          <div className="flex flex-col gap-2">
            <label className="font-sans font-semibold text-sm text-gray-200">Meals Per Day</label>
            <div className="grid grid-cols-3 gap-2">
              {[2, 3, 4].map((count) => (
                <button
                  key={count}
                  type="button"
                  onClick={() => setMealsPerDay(count)}
                  className={`py-2 px-3 rounded-lg text-xs font-mono border transition-all ${
                    mealsPerDay === count
                      ? "bg-blue-500/20 border-blue-500/50 text-blue-300 font-semibold"
                      : "bg-[#0e0e0f] border-white/5 text-gray-400 hover:border-white/10 hover:text-white"
                  }`}
                >
                  {count} Meals
                </button>
              ))}
            </div>
          </div>

          {/* Ingredient exclusions */}
          <div className="flex flex-col gap-2">
            <label className="font-sans font-semibold text-sm text-gray-200">Exclude Ingredients</label>
            <form onSubmit={handleAddExclusion} className="flex gap-2">
              <input
                type="text"
                placeholder="e.g., dairy, peanuts, gluten"
                value={newExclusion}
                onChange={(e) => setNewExclusion(e.target.value)}
                className="bg-[#0e0e0f] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 transition-colors flex-grow"
              />
              <button
                type="submit"
                className="p-2 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 text-white transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </form>

            <div className="flex flex-wrap gap-1.5 mt-2 max-h-[100px] overflow-y-auto pr-1">
              {excluded.length === 0 && (
                <span className="text-xs text-gray-500 font-mono italic">No active exclusions.</span>
              )}
              {excluded.map((ing) => (
                <span
                  key={ing}
                  className="inline-flex items-center gap-1 text-[10px] font-mono bg-red-500/5 border border-red-500/10 text-red-400 px-2.5 py-1 rounded"
                >
                  <span>{ing}</span>
                  <X
                    className="w-3 h-3 hover:text-red-300 cursor-pointer"
                    onClick={() => handleRemoveExclusion(ing)}
                  />
                </span>
              ))}
            </div>
          </div>

          {/* Action Trigger */}
          <button
            onClick={generateMealPlan}
            disabled={loading}
            className={`w-full py-3.5 mt-2 rounded-lg font-mono text-xs uppercase tracking-wider font-semibold flex items-center justify-center gap-2 transition-all ${
              loading
                ? "bg-blue-500/10 border border-blue-500/20 text-blue-400 cursor-not-allowed"
                : "bg-blue-500 hover:bg-blue-600 text-white cursor-pointer hover:shadow-[0_0_15px_rgba(59,130,246,0.4)] active:scale-95"
            }`}
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Processing...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Generate Meal Plan</span>
              </>
            )}
          </button>
        </div>

        {/* Right Output Display Column */}
        <div className="lg:col-span-8 flex flex-col h-full min-h-[400px]">
          {/* Welcome view (No generation yet) */}
          {!loading && !mealPlan && !error && (
            <div className="flex-grow flex flex-col items-center justify-center text-center p-8 border border-dashed border-white/5 rounded-xl bg-white/[0.01]">
              <div className="w-12 h-12 rounded-full bg-blue-500/5 border border-blue-500/10 flex items-center justify-center mb-4">
                <Sparkles className="w-6 h-6 text-blue-400/80 animate-pulse" />
              </div>
              <h5 className="font-sans font-semibold text-white text-base mb-1">Interactive Meal Plan Generator</h5>
              <p className="text-xs text-gray-500 max-w-sm leading-relaxed">
                Choose your dietary requirements on the left sidebar, click generate, and see the Gemini API draft a fully customized meal plan in real time!
              </p>
            </div>
          )}

          {/* Loading view */}
          {loading && (
            <div className="flex-grow flex flex-col items-center justify-center text-center p-8 bg-[#0e0e0f]/30 border border-white/10 rounded-xl">
              <div className="relative w-16 h-16 flex items-center justify-center mb-6">
                <div className="absolute inset-0 border-4 border-blue-500/20 rounded-full" />
                <div className="absolute inset-0 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
                <Utensils className="w-6 h-6 text-blue-400" />
              </div>
              <h5 className="font-mono text-sm text-blue-400 font-semibold mb-2 animate-pulse">
                {loadingStep || "Analyzing criteria..."}
              </h5>
              <p className="text-xs text-gray-500 max-w-sm">
                Generating rich structured recipe outputs. This process utilizes the server-side Gemini proxy and may take 5-10 seconds.
              </p>
            </div>
          )}

          {/* Error view */}
          {error && (
            <div className="flex-grow flex flex-col items-center justify-center text-center p-8 bg-red-500/5 border border-red-500/10 rounded-xl">
              <div className="p-3 bg-red-500/10 rounded-full mb-3 text-red-400">
                <AlertCircle className="w-8 h-8" />
              </div>
              <h5 className="font-sans font-semibold text-white text-base mb-1">Generation Process Halted</h5>
              <p className="text-xs text-red-300 max-w-md leading-relaxed">{error}</p>
              <button
                onClick={generateMealPlan}
                className="mt-4 px-4 py-2 bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-mono rounded hover:bg-red-500/20 transition-all"
              >
                Retry Generation
              </button>
            </div>
          )}

          {/* Completed view */}
          {mealPlan && (
            <div className="flex-grow flex flex-col gap-6 animate-fade-in">
              {/* Plan metrics card */}
              <div className="flex items-center justify-between p-4 bg-blue-500/5 border border-blue-500/15 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 border border-blue-500/10">
                    <Calculator className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">Aggregate Energy Output</span>
                    <h5 className="font-sans font-bold text-white text-lg">Daily Nutritional Budget</h5>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono text-gray-400 block uppercase">Target Achieved</span>
                  <span className="font-mono text-xl font-bold text-blue-400">{mealPlan.total_calories} kcal</span>
                </div>
              </div>

              {/* Scrollable list of meals */}
              <div className="flex flex-col gap-4 max-h-[500px] overflow-y-auto pr-1">
                {mealPlan.meals.map((meal: Meal, idx: number) => (
                  <div
                    key={idx}
                    className="p-5 bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 hover:border-white/10 rounded-xl transition-all"
                  >
                    {/* Header: type & macro pills */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/5 mb-4">
                      <div>
                        <span className="font-mono text-[10px] text-blue-400 uppercase font-bold tracking-wider mr-2">
                          {meal.type}
                        </span>
                        <h6 className="font-sans font-bold text-white text-base inline-block">{meal.name}</h6>
                      </div>
                      <div className="flex gap-1.5 flex-wrap">
                        <span className="text-[9px] font-mono bg-white/5 text-gray-300 px-2 py-0.5 rounded">
                          P: {meal.macros.protein}
                        </span>
                        <span className="text-[9px] font-mono bg-white/5 text-gray-300 px-2 py-0.5 rounded">
                          C: {meal.macros.carbs}
                        </span>
                        <span className="text-[9px] font-mono bg-white/5 text-gray-300 px-2 py-0.5 rounded">
                          F: {meal.macros.fat}
                        </span>
                      </div>
                    </div>

                    {/* Split content: Ingredients and instructions */}
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                      {/* Ingredients */}
                      <div className="md:col-span-5 flex flex-col gap-2">
                        <span className="text-[10px] font-mono uppercase text-gray-400 tracking-wider">
                          Ingredients
                        </span>
                        <ul className="flex flex-col gap-1 text-xs text-gray-300">
                          {meal.ingredients.map((ing, i) => (
                            <li key={i} className="flex items-center gap-1.5 leading-relaxed">
                              <ChevronRight className="w-3 h-3 text-blue-400 flex-shrink-0" />
                              <span>{ing}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Instructions */}
                      <div className="md:col-span-7 flex flex-col gap-2">
                        <span className="text-[10px] font-mono uppercase text-gray-400 tracking-wider">
                          Preparation Steps
                        </span>
                        <ol className="flex flex-col gap-1.5 text-xs text-gray-300 list-decimal pl-4">
                          {meal.instructions.map((step, i) => (
                            <li key={i} className="leading-relaxed pl-1">
                              {step}
                            </li>
                          ))}
                        </ol>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
