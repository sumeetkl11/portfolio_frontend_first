import React, { useRef, useEffect, useState } from "react";
import { ArrowDown, Code, Cpu, Layers } from "lucide-react";

export default function Hero() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const [coords, setCoords] = useState({ x: 0, y: 0 });
  const [hovered, setHovered] = useState(false);

  // Smooth mouse coordinates tracking for 3D perspective effect
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const container = containerRef.current;
    if (!container) return;

    const { left, top, width, height } = container.getBoundingClientRect();
    const x = (e.clientX - left) / width - 0.5;
    const y = (e.clientY - top) / height - 0.5;

    setCoords({ x, y });
  };

  const handleMouseLeave = () => {
    setHovered(false);
    setCoords({ x: 0, y: 0 });
  };

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  // Profile image transform string based on interactive coordinate physics
  const transformStyle = hovered
    ? `perspective(1000px) rotateY(${coords.x * 24}deg) rotateX(${-coords.y * 24}deg) scale3d(1.04, 1.04, 1.04)`
    : "perspective(1000px) rotateY(0deg) rotateX(0deg) scale3d(1, 1, 1)";

  return (
    <section className="min-h-[calc(100vh-80px)] flex items-center justify-center px-6 relative z-10 pt-[100px] md:pt-0">
      <div className="max-w-[1200px] w-full mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        
        {/* Left column: Bio & Actions */}
        <div className="md:col-span-7 flex flex-col gap-6 text-left">
          <div className="animate-fade-in">
            {/* System Status Label */}
            <span className="inline-flex items-center gap-1.5 font-mono text-xs text-blue-400 px-3 py-1 rounded-full bg-white/5 border border-white/10 mb-5">
              <Cpu className="w-3.5 h-3.5 animate-pulse" />
              <span>System Initialized v1.0</span>
            </span>

            {/* Display Heading */}
            <h1 className="font-sans font-extrabold text-4xl md:text-6xl text-white tracking-tight leading-none mb-4">
              Hi, I'm <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-500 font-extrabold pb-1 inline-block">
                Sumeet Kanhiya.
              </span>
            </h1>
          </div>

          <p className="font-sans text-lg text-gray-300 max-w-xl leading-relaxed">
            Full Stack Developer specializing in the PERN stack and scalable, performant web architectures. Crafting highly optimized user experiences integrated with secure server proxies.
          </p>

          {/* Tag Pills */}
          <div className="flex flex-wrap gap-2.5 my-2">
            {["PERN Stack", "React.js", "Node.js", "TypeScript", "AI Engineering"].map((tech) => (
              <span
                key={tech}
                className="font-mono text-xs bg-white/5 text-gray-400 border border-white/10 px-3 py-1 rounded-full flex items-center gap-1"
              >
                <Code className="w-3 h-3 text-blue-400" />
                {tech}
              </span>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-wrap gap-4 mt-4">
            <button
              onClick={() => scrollTo("projects")}
              className="px-8 py-3.5 bg-blue-500 hover:bg-blue-600 text-white font-mono text-xs font-semibold rounded uppercase tracking-wider transition-all duration-300 hover:shadow-[0_0_20px_rgba(59,130,246,0.5)] transform hover:scale-105 active:scale-95 cursor-pointer"
            >
              Explore Projects
            </button>
            <button
              onClick={() => scrollTo("contact")}
              className="px-8 py-3.5 bg-transparent border border-white/10 hover:border-blue-400 text-white font-mono text-xs font-semibold rounded uppercase tracking-wider hover:bg-blue-500/10 transition-all duration-300 transform hover:scale-105 active:scale-95 cursor-pointer"
            >
              Initialize Contact
            </button>
          </div>
        </div>

        {/* Right column: Interactive Profile Image */}
        <div
          ref={containerRef}
          onMouseMove={handleMouseMove}
          onMouseEnter={() => setHovered(true)}
          onMouseLeave={handleMouseLeave}
          className="md:col-span-5 flex justify-center mt-10 md:mt-0 relative z-10 cursor-pointer"
        >
          {/* Subtle Backglow Circle */}
          <div className="absolute inset-0 bg-blue-500/10 blur-[60px] rounded-full pointer-events-none transform scale-75 animate-pulse" />

          {/* Profile Image Wrapper */}
          <div
            className="relative transition-transform duration-200 ease-out p-1 rounded-2xl bg-gradient-to-tr from-blue-500/30 to-purple-500/30 border border-white/10 overflow-hidden"
            style={{ transform: transformStyle }}
          >
            <img
              ref={imgRef}
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCPKbVozYWDidB_vMtDeKGVV9T0J8yyLcUSLqh1shUAb59Cej2CQaMDtBwFcU0wMfP7OJQ7ueBFD3NsDujxvnJqpwyZ8g3ECD68Diqoeq5nn1ITYUvzpsffkXqMva2DpmErToUf-GK182aqfs0NQwOsikDJ26lvjBWQDQ6xwInQUqWs0kQfcad3unhmWnpP9vOgr4DXnyylwQu33YSSnqR4LJqHHsMahO_mzvlMF0LqPrlZVUt0IbMsXJESZzb5aRJgkgW_PE5OYFQ"
              alt="Sumeet Kanhiya Profile"
              referrerPolicy="no-referrer"
              className="w-64 md:w-80 h-auto aspect-square object-cover rounded-xl shadow-2xl filter brightness-95"
            />
            {/* Hologram Overlay Lines */}
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-blue-500/5 to-transparent pointer-events-none mix-blend-overlay" />
          </div>
        </div>

      </div>

      {/* Scroll indicator */}
      <div
        onClick={() => scrollTo("projects")}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 cursor-pointer group opacity-60 hover:opacity-100 transition-opacity"
      >
        <span className="font-mono text-[10px] uppercase tracking-widest text-gray-400 group-hover:text-blue-400 transition-colors">
          Scroll to Explore
        </span>
        <ArrowDown className="w-4 h-4 text-blue-400 animate-bounce" />
      </div>
    </section>
  );
}
