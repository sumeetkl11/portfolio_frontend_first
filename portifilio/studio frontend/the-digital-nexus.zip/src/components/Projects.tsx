import React, { useState } from "react";
import TastebudsDemo from "./TastebudsDemo";
import { Code, ExternalLink, Sparkles, MessageSquare, Link as LinkIcon, Database, CheckCircle2, ChevronRight, Play } from "lucide-react";

export default function Projects() {
  const [activeDemo, setActiveDemo] = useState<string>("none");

  // Local state for SocialConnect Chat simulator
  const [chatMessages, setChatMessages] = useState([
    { sender: "Sumeet (Bot)", text: "Welcome to SocialConnect! Our server is fully running over WebSocket emulation.", time: "System Log" },
    { sender: "System", text: "[Database] Initialized PostgreSQL connection pool. Listening for client frames...", time: "System Log" },
  ]);
  const [newChatText, setNewChatText] = useState("");
  const [dbLogs, setDbLogs] = useState<string[]>([
    "CONNECTED to PostgreSQL database on port 5432",
    "INITIALIZED Websocket Server on port 8080",
  ]);

  // Local state for Linkforge URL shorter
  const [shortLinks, setShortLinks] = useState<Array<{ shortCode: string; longUrl: string; clicks: number; latency: string }>>([
    { shortCode: "gmn3", longUrl: "https://ai.studio/build", clicks: 12, latency: "24ms" },
    { shortCode: "por1", longUrl: "https://github.com/sumeetkl11", clicks: 84, latency: "18ms" }
  ]);
  const [longUrl, setLongUrl] = useState("");
  const [customAlias, setCustomAlias] = useState("");

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChatText.trim()) return;

    const userMsg = { sender: "You", text: newChatText, time: new Date().toLocaleTimeString() };
    setChatMessages((prev) => [...prev, userMsg]);
    setNewChatText("");

    // Simulate real database logs and socket events
    const log1 = `[WebSocket] FRAME_RECEIVED from client: "${userMsg.text.substring(0, 15)}..."`;
    const log2 = `[Database] INSERT INTO "Messages" (id, sender, content) VALUES (uuid_generate_v4(), 'User', '${userMsg.text.replace(/'/g, "''")}')`;
    const log3 = `[Database] Query executed in 14ms - Committed transaction.`;
    setDbLogs((prev) => [...prev, log1, log2, log3]);

    // Simulate Sumeet's backend bot replying
    setTimeout(() => {
      const replyText = getBotReply(userMsg.text);
      setChatMessages((prev) => [...prev, { sender: "Sumeet (Bot)", text: replyText, time: new Date().toLocaleTimeString() }]);
      setDbLogs((prev) => [...prev, `[WebSocket] SENDING event "message_receipt" to client`, `[Database] Logged API analytics packet.`]);
    }, 1500);
  };

  const getBotReply = (text: string) => {
    const t = text.toLowerCase();
    if (t.includes("hello") || t.includes("hi")) return "Greetings developer! Yes, this chat is a live simulation of a real WebSocket architecture. Ask me about my stack!";
    if (t.includes("stack") || t.includes("tech")) return "SocialConnect is built with a Node.js/Express.js backend, a native WebSocket connection layer, and a highly normalized PostgreSQL database. Perfect for low-latency delivery.";
    if (t.includes("postgres") || t.includes("sql")) return "Postgres ensures total ACID compliance! For messaging, we index the composite timestamps and handle connection pools efficiently.";
    return "Fascinating query! In a real environment, this trigger syncs state cleanly across clients. Try querying or chatting further!";
  };

  const handleShortenUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!longUrl.trim()) return;

    const code = customAlias.trim() || Math.random().toString(36).substring(2, 6);
    const newLink = {
      shortCode: code,
      longUrl: longUrl,
      clicks: 0,
      latency: `${Math.floor(Math.random() * 15 + 10)}ms`
    };

    setShortLinks((prev) => [newLink, ...prev]);
    setLongUrl("");
    setCustomAlias("");
  };

  const handleIncrementClick = (code: string) => {
    setShortLinks((prev) =>
      prev.map((link) => {
        if (link.shortCode === code) {
          return { ...link, clicks: link.clicks + 1 };
        }
        return link;
      })
    );
  };

  return (
    <section id="projects" className="py-24 px-6 relative z-10 max-w-[1200px] mx-auto">
      {/* Title */}
      <div className="mb-16 text-center">
        <span className="font-mono text-xs text-blue-400 font-semibold px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 uppercase tracking-widest inline-block mb-3 animate-pulse">
          Crafted Engineering
        </span>
        <h2 className="font-sans font-extrabold text-4xl md:text-5xl text-white tracking-tight leading-none mb-3">
          Featured Projects
        </h2>
        <p className="font-sans text-gray-400 text-base max-w-xl mx-auto">
          Production-grade architectures designed with optimized data modeling, clean caching layers, and high structural performance. Click **Initialize Live Sandbox** to run them.
        </p>
      </div>

      {/* Grid of 3 Project Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
        
        {/* Project 1: Tastebuds */}
        <div className="bg-[#1c1b1c]/30 backdrop-blur-md rounded-2xl border border-white/10 p-6 flex flex-col h-full hover:border-blue-500/40 hover:-translate-y-1.5 transition-all duration-300 shadow-xl">
          <h3 className="font-sans font-bold text-xl text-blue-400 mb-2">Tastebuds</h3>
          <div className="flex flex-wrap gap-1.5 mb-4">
            {["Node.js", "Express.js", "PostgreSQL", "Gemini API"].map((tag) => (
              <span key={tag} className="font-mono text-[9px] bg-blue-500/10 border border-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full">
                {tag}
              </span>
            ))}
          </div>
          <p className="text-sm text-gray-300 leading-relaxed mb-4 flex-grow">
            An intelligent meal-planning platform leveraging AI-driven recipe generation with dynamic filtering for dietary preferences and ingredient restrictions.
          </p>
          <ul className="text-xs text-gray-400 flex flex-col gap-1.5 mb-6">
            <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-blue-400" /> Engineered RESTful API backend</li>
            <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-blue-400" /> Integrated Gemini API prompts</li>
            <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-blue-400" /> Automated meal-plan schemas</li>
          </ul>
          <div className="flex gap-4 items-center">
            <a href="https://github.com/sumeetkl11/tastebuds" target="_blank" rel="noopener noreferrer" className="text-xs font-mono text-gray-400 hover:text-white flex items-center gap-1 transition-colors">
              <Code className="w-4 h-4" /> Code
            </a>
            <button onClick={() => { setActiveDemo("tastebuds"); document.getElementById("sandbox-deck")?.scrollIntoView({ behavior: "smooth" }); }} className="text-xs font-mono text-blue-400 hover:text-blue-300 flex items-center gap-1 transition-colors font-bold cursor-pointer">
              <Play className="w-3 h-3" /> Initialize Live Sandbox
            </button>
          </div>
        </div>

        {/* Project 2: SocialConnect */}
        <div className="bg-[#1c1b1c]/30 backdrop-blur-md rounded-2xl border border-white/10 p-6 flex flex-col h-full hover:border-purple-500/40 hover:-translate-y-1.5 transition-all duration-300 shadow-xl">
          <h3 className="font-sans font-bold text-xl text-purple-400 mb-2">SocialConnect</h3>
          <div className="flex flex-wrap gap-1.5 mb-4">
            {["WebSockets", "Node.js", "Express.js", "PostgreSQL", "JavaScript"].map((tag) => (
              <span key={tag} className="font-mono text-[9px] bg-purple-500/10 border border-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full">
                {tag}
              </span>
            ))}
          </div>
          <p className="text-sm text-gray-300 leading-relaxed mb-4 flex-grow">
            Designed a low-latency real-time messaging architecture, incorporating custom client-server socket envelopes and high-concurrency database queries.
          </p>
          <ul className="text-xs text-gray-400 flex flex-col gap-1.5 mb-6">
            <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-purple-400" /> Scalable WebSocket servers</li>
            <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-purple-400" /> Relational database modeling</li>
            <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-purple-400" /> Cross-origin authentication</li>
          </ul>
          <div className="flex gap-4 items-center">
            <a href="https://github.com/sumeetkl11/socialconnect" target="_blank" rel="noopener noreferrer" className="text-xs font-mono text-gray-400 hover:text-white flex items-center gap-1 transition-colors">
              <Code className="w-4 h-4" /> Code
            </a>
            <button onClick={() => { setActiveDemo("socialconnect"); document.getElementById("sandbox-deck")?.scrollIntoView({ behavior: "smooth" }); }} className="text-xs font-mono text-purple-400 hover:text-purple-300 flex items-center gap-1 transition-colors font-bold cursor-pointer">
              <Play className="w-3 h-3" /> Initialize Live Sandbox
            </button>
          </div>
        </div>

        {/* Project 3: Linkforge */}
        <div className="bg-[#1c1b1c]/30 backdrop-blur-md rounded-2xl border border-white/10 p-6 flex flex-col h-full hover:border-blue-500/40 hover:-translate-y-1.5 transition-all duration-300 shadow-xl">
          <h3 className="font-sans font-bold text-xl text-blue-400 mb-2">Linkforge</h3>
          <div className="flex flex-wrap gap-1.5 mb-4">
            {["React.js", "Node.js", "Express.js", "Tailwind CSS"].map((tag) => (
              <span key={tag} className="font-mono text-[9px] bg-blue-500/10 border border-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full">
                {tag}
              </span>
            ))}
          </div>
          <p className="text-sm text-gray-300 leading-relaxed mb-4 flex-grow">
            A streamlined full-stack utility tool built to manage, optimize, and safely redirect digital link structures with real-time tracking metrics.
          </p>
          <ul className="text-xs text-gray-400 flex flex-col gap-1.5 mb-6">
            <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-blue-400" /> Fast redirection mapping</li>
            <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-blue-400" /> Semantic, modular codebase</li>
            <li className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-blue-400" /> Fluid, responsive layout</li>
          </ul>
          <div className="flex gap-4 items-center">
            <a href="https://github.com/sumeetkl11/linkforge" target="_blank" rel="noopener noreferrer" className="text-xs font-mono text-gray-400 hover:text-white flex items-center gap-1 transition-colors">
              <Code className="w-4 h-4" /> Code
            </a>
            <button onClick={() => { setActiveDemo("linkforge"); document.getElementById("sandbox-deck")?.scrollIntoView({ behavior: "smooth" }); }} className="text-xs font-mono text-blue-400 hover:text-blue-300 flex items-center gap-1 transition-colors font-bold cursor-pointer">
              <Play className="w-3 h-3" /> Initialize Live Sandbox
            </button>
          </div>
        </div>

      </div>

      {/* Sandbox Anchor Element */}
      <div id="sandbox-deck" className="w-full">
        {activeDemo === "tastebuds" && (
          <div className="animate-fade-in relative">
            <button onClick={() => setActiveDemo("none")} className="absolute top-4 right-4 text-xs font-mono bg-white/5 hover:bg-white/10 px-3 py-1 border border-white/10 hover:border-white/20 text-gray-300 rounded cursor-pointer transition-all z-10">
              Close Sandbox
            </button>
            <TastebudsDemo />
          </div>
        )}

        {activeDemo === "socialconnect" && (
          <div className="animate-fade-in relative bg-[#1c1b1c]/40 backdrop-blur-md rounded-2xl border border-white/10 p-6 md:p-8 shadow-2xl">
            <button onClick={() => setActiveDemo("none")} className="absolute top-4 right-4 text-xs font-mono bg-white/5 hover:bg-white/10 px-3 py-1 border border-white/10 hover:border-white/20 text-gray-300 rounded cursor-pointer transition-all z-10">
              Close Sandbox
            </button>

            {/* Title block */}
            <div className="pb-6 border-b border-white/10 mb-6">
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 bg-purple-500/10 border border-purple-500/20 text-purple-400 font-mono text-[10px] rounded-full uppercase tracking-wider">
                  WebSocket Emulation Sandbox
                </span>
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="font-mono text-[10px] text-gray-400">Node.js Server Up</span>
              </div>
              <h4 className="font-sans font-bold text-2xl text-white">SocialConnect Socket Playground</h4>
              <p className="text-xs text-gray-400 max-w-xl">
                Chat in real-time. Witness live logs printing relational database insert updates and socket communication envelopes side-by-side.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Chat interface */}
              <div className="lg:col-span-7 bg-[#0e0e0f] rounded-xl border border-white/5 overflow-hidden flex flex-col h-[400px]">
                <div className="bg-white/[0.01] px-4 py-3 border-b border-white/5 flex justify-between items-center">
                  <span className="font-mono text-xs text-gray-300 flex items-center gap-1.5">
                    <MessageSquare className="w-4 h-4 text-purple-400" />
                    <span>Socket Room: general_lobby</span>
                  </span>
                  <span className="text-[10px] font-mono text-green-400 bg-green-500/5 px-2 py-0.5 border border-green-500/10 rounded">
                    ● ACTIVE
                  </span>
                </div>

                {/* Messages scrollarea */}
                <div className="flex-grow p-4 overflow-y-auto flex flex-col gap-3">
                  {chatMessages.map((msg, idx) => (
                    <div key={idx} className={`flex flex-col max-w-[80%] ${msg.sender === "You" ? "ml-auto items-end" : "mr-auto items-start"}`}>
                      <div className="flex items-baseline gap-2 mb-1">
                        <span className="text-[10px] font-mono font-bold text-purple-400">{msg.sender}</span>
                        <span className="text-[8px] font-mono text-gray-500">{msg.time}</span>
                      </div>
                      <div className={`p-3 text-xs rounded-xl ${
                        msg.sender === "You"
                          ? "bg-purple-500/20 text-purple-100 rounded-tr-none border border-purple-500/30"
                          : msg.sender === "System"
                          ? "bg-white/5 text-gray-400 font-mono text-[10px] italic border border-white/5"
                          : "bg-white/[0.03] text-gray-200 rounded-tl-none border border-white/5"
                      }`}>
                        {msg.text}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Input form */}
                <form onSubmit={handleSendChat} className="p-3 bg-white/[0.01] border-t border-white/5 flex gap-2">
                  <input
                    type="text"
                    placeholder="Type a query or message (e.g., 'What is your PostgreSQL schema?')..."
                    value={newChatText}
                    onChange={(e) => setNewChatText(e.target.value)}
                    className="flex-grow bg-[#050505] border border-white/15 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500 transition-colors"
                  />
                  <button type="submit" className="bg-purple-500 hover:bg-purple-600 px-4 py-2 text-white font-mono text-xs rounded-lg transition-all cursor-pointer">
                    Send
                  </button>
                </form>
              </div>

              {/* Server Database logs */}
              <div className="lg:col-span-5 bg-[#0e0e0f] rounded-xl border border-white/5 overflow-hidden flex flex-col h-[400px]">
                <div className="bg-white/[0.01] px-4 py-3 border-b border-white/5 flex items-center gap-1.5">
                  <Database className="w-4 h-4 text-purple-400" />
                  <span className="font-mono text-xs text-gray-300">Live Relational SQL Logs</span>
                </div>
                <div className="flex-grow p-4 font-mono text-[10px] text-green-400 overflow-y-auto flex flex-col gap-2 bg-[#050505] select-text">
                  {dbLogs.map((log, idx) => (
                    <div key={idx} className="leading-normal pb-1 border-b border-white/5">
                      <span className="text-gray-500 select-none mr-1.5">&gt;&gt;</span>
                      <span>{log}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeDemo === "linkforge" && (
          <div className="animate-fade-in relative bg-[#1c1b1c]/40 backdrop-blur-md rounded-2xl border border-white/10 p-6 md:p-8 shadow-2xl">
            <button onClick={() => setActiveDemo("none")} className="absolute top-4 right-4 text-xs font-mono bg-white/5 hover:bg-white/10 px-3 py-1 border border-white/10 hover:border-white/20 text-gray-300 rounded cursor-pointer transition-all z-10">
              Close Sandbox
            </button>

            {/* Title block */}
            <div className="pb-6 border-b border-white/10 mb-6">
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 bg-blue-500/10 border border-blue-500/20 text-blue-400 font-mono text-[10px] rounded-full uppercase tracking-wider">
                  Link Optimization Utility
                </span>
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="font-mono text-[10px] text-gray-400">Microservice Connected</span>
              </div>
              <h4 className="font-sans font-bold text-2xl text-white">Linkforge Redirector Sandbox</h4>
              <p className="text-xs text-gray-400 max-w-xl">
                Create real shortened links, simulate high-velocity click hits, and watch the redirection latency profiles update live.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Creator Form */}
              <div className="lg:col-span-5 bg-[#0e0e0f]/50 p-5 rounded-xl border border-white/5 flex flex-col gap-4">
                <h5 className="font-sans font-semibold text-sm text-white">Optimize New Link</h5>
                <form onSubmit={handleShortenUrl} className="flex flex-col gap-3">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-mono text-gray-400 uppercase">Long Target URL</label>
                    <input
                      type="url"
                      required
                      placeholder="https://example.com/very/long/unfriendly/path"
                      value={longUrl}
                      onChange={(e) => setLongUrl(e.target.value)}
                      className="bg-[#050505] border border-white/15 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-mono text-gray-400 uppercase">Custom Slug (Optional)</label>
                    <div className="flex items-center bg-[#050505] border border-white/15 rounded overflow-hidden">
                      <span className="text-[11px] text-gray-500 font-mono px-2 select-none border-r border-white/10">nexus.co/</span>
                      <input
                        type="text"
                        placeholder="my-link"
                        value={customAlias}
                        onChange={(e) => setCustomAlias(e.target.value)}
                        className="bg-transparent border-none flex-grow px-2 py-2 text-xs text-white focus:outline-none"
                      />
                    </div>
                  </div>
                  <button type="submit" className="w-full bg-blue-500 hover:bg-blue-600 py-2.5 text-white font-mono text-xs uppercase tracking-wider font-semibold rounded cursor-pointer transition-all mt-1">
                    Forge Link
                  </button>
                </form>
              </div>

              {/* Links database list */}
              <div className="lg:col-span-7 bg-[#0e0e0f]/50 p-5 rounded-xl border border-white/5 flex flex-col gap-4">
                <h5 className="font-sans font-semibold text-sm text-white flex items-center gap-1.5">
                  <LinkIcon className="w-4 h-4 text-blue-400" />
                  <span>Forged Database Links</span>
                </h5>
                <div className="flex flex-col gap-3 max-h-[250px] overflow-y-auto pr-1">
                  {shortLinks.map((link) => (
                    <div key={link.shortCode} className="p-3 bg-[#050505] border border-white/5 rounded flex justify-between items-center hover:border-white/15 transition-all">
                      <div className="flex flex-col gap-1 max-w-[65%]">
                        <span className="font-mono text-xs text-blue-400 font-bold select-all">nexus.co/{link.shortCode}</span>
                        <span className="text-[10px] text-gray-500 font-mono truncate select-text">{link.longUrl}</span>
                      </div>
                      <div className="flex items-center gap-4 text-right">
                        <div>
                          <span className="text-[8px] font-mono text-gray-500 block">LATENCY</span>
                          <span className="font-mono text-xs text-green-400">{link.latency}</span>
                        </div>
                        <div>
                          <span className="text-[8px] font-mono text-gray-500 block">TOTAL CLICKS</span>
                          <span className="font-mono text-xs text-white font-bold">{link.clicks}</span>
                        </div>
                        <button
                          onClick={() => handleIncrementClick(link.shortCode)}
                          className="px-2.5 py-1.5 bg-blue-500/10 border border-blue-500/20 text-blue-400 hover:bg-blue-500/20 hover:border-blue-500/40 text-[10px] font-mono rounded cursor-pointer transition-all flex items-center gap-1"
                        >
                          <ExternalLink className="w-3 h-3" /> Hit
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
