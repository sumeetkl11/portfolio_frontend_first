import { useEffect, useRef } from "react";

export default function BackgroundCanvas() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = 0;
    let height = 0;
    let scrollY = 0;

    // Torus knot parameters
    const p = 3;
    const q = 7;
    const torusPoints: { x: number; y: number; z: number }[] = [];
    const numPoints = 180;

    // Generate points for the Torus Knot
    for (let i = 0; i < numPoints; i++) {
      const phi = (i / numPoints) * Math.PI * 2;
      const r = 4 * Math.cos(q * phi) + 10;
      const x = r * Math.cos(p * phi);
      const y = r * Math.sin(p * phi);
      const z = -6 * Math.sin(q * phi);
      torusPoints.push({ x, y, z });
    }

    // Particle settings
    const numParticles = 120;
    const particles: { x: number; y: number; z: number; size: number; speed: number }[] = [];
    for (let i = 0; i < numParticles; i++) {
      particles.push({
        x: (Math.random() - 0.5) * 80,
        y: (Math.random() - 0.5) * 80,
        z: (Math.random() - 0.5) * 80,
        size: Math.random() * 1.5 + 0.5,
        speed: Math.random() * 0.05 + 0.02,
      });
    }

    // Handle Resize (Limiting resolution scaling on high-DPI displays for 60fps performance)
    const handleResize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.scale(dpr, dpr);
    };

    // Track scroll
    const handleScroll = () => {
      scrollY = window.scrollY;
    };

    window.addEventListener("resize", handleResize);
    window.addEventListener("scroll", handleScroll);
    handleResize();

    let angleX = 0;
    let angleY = 0;

    // Render loop
    const render = () => {
      // Background base clear
      ctx.fillStyle = "#131314";
      ctx.fillRect(0, 0, width, height);

      // Perspective projection parameters
      const fov = 400;
      const centerX = width / 2;
      // Scroll shifts the center slightly for an immersive parallax effect
      const centerY = height / 2 - scrollY * 0.15;

      // Incremental slow rotations
      angleX += 0.003;
      angleY += 0.002;

      // 3D rotation math helper
      const rotateX = (x: number, y: number, z: number, theta: number) => {
        const cos = Math.cos(theta);
        const sin = Math.sin(theta);
        return {
          x,
          y: y * cos - z * sin,
          z: y * sin + z * cos,
        };
      };

      const rotateY = (x: number, y: number, z: number, theta: number) => {
        const cos = Math.cos(theta);
        const sin = Math.sin(theta);
        return {
          x: x * cos + z * sin,
          y,
          z: -x * sin + z * cos,
        };
      };

      // 1. Draw glowing background grid lines/ambience (cyber feel)
      ctx.strokeStyle = "rgba(59, 130, 246, 0.03)";
      ctx.lineWidth = 1;
      const gridSize = 80;
      for (let xCoord = 0; xCoord < width; xCoord += gridSize) {
        ctx.beginPath();
        ctx.moveTo(xCoord, 0);
        ctx.lineTo(xCoord, height);
        ctx.stroke();
      }
      for (let yCoord = 0; yCoord < height; yCoord += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, yCoord);
        ctx.lineTo(width, yCoord);
        ctx.stroke();
      }

      // 2. Draw 3D Particles
      particles.forEach((p) => {
        // Slow particle translation
        p.z -= p.speed;
        if (p.z < -40) p.z = 40; // wrap back

        // Rotate particles
        let rotated = rotateX(p.x, p.y, p.z, angleX * 0.2);
        rotated = rotateY(rotated.x, rotated.y, rotated.z, angleY * 0.2);

        // Perspective projection
        const scale = fov / (fov + rotated.z + 100);
        const sx = centerX + rotated.x * scale * 8;
        const sy = centerY + rotated.y * scale * 8;

        if (sx >= 0 && sx <= width && sy >= 0 && sy <= height) {
          const alpha = Math.max(0, Math.min(1, (rotated.z + 40) / 80)) * 0.4;
          ctx.fillStyle = `rgba(139, 92, 246, ${alpha})`;
          ctx.beginPath();
          ctx.arc(sx, sy, p.size * scale, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      // 3. Draw 3D Torus Knot Wireframe
      ctx.beginPath();
      let first = true;
      const projectedPoints: { x: number; y: number; z: number }[] = [];

      torusPoints.forEach((point) => {
        // Rotate the torus knot
        let rotated = rotateX(point.x, point.y, point.z, angleX);
        rotated = rotateY(rotated.x, rotated.y, rotated.z, angleY);

        // Scroll influence rotation
        rotated = rotateX(rotated.x, rotated.y, rotated.z, scrollY * 0.0005);

        // Perspective Projection
        const scale = fov / (fov + rotated.z + 40);
        // Base coordinate size scaling
        const sizeMult = Math.min(width, height) / 45;
        const sx = centerX + rotated.x * scale * sizeMult;
        const sy = centerY + rotated.y * scale * sizeMult;

        projectedPoints.push({ x: sx, y: sy, z: rotated.z });
      });

      // Draw lines connecting the points
      ctx.lineWidth = 1.2;
      for (let i = 0; i < projectedPoints.length; i++) {
        const pt = projectedPoints[i];
        const nextPt = projectedPoints[(i + 1) % projectedPoints.length];

        // Depth cue coloring (fade parts further away)
        const avgZ = (pt.z + nextPt.z) / 2;
        const alpha = Math.max(0.04, Math.min(0.28, (avgZ + 15) / 30));

        // Create glowing stroke style transition (blue to violet)
        const pct = i / projectedPoints.length;
        const rValue = Math.floor(59 * (1 - pct) + 139 * pct);
        const gValue = Math.floor(130 * (1 - pct) + 92 * pct);
        const bValue = Math.floor(246 * (1 - pct) + 246 * pct);

        ctx.strokeStyle = `rgba(${rValue}, ${gValue}, ${bValue}, ${alpha})`;

        ctx.beginPath();
        ctx.moveTo(pt.x, pt.y);
        ctx.lineTo(nextPt.x, nextPt.y);
        ctx.stroke();

        // Optional cross-webbing to make it look even more complex and structural
        if (i % 6 === 0) {
          const crossPt = projectedPoints[(i + 40) % projectedPoints.length];
          ctx.strokeStyle = `rgba(59, 130, 246, ${alpha * 0.15})`;
          ctx.beginPath();
          ctx.moveTo(pt.x, pt.y);
          ctx.lineTo(crossPt.x, crossPt.y);
          ctx.stroke();
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <canvas
      id="bg-canvas"
      ref={canvasRef}
      className="fixed inset-0 w-full h-full -z-10 pointer-events-none"
    />
  );
}
