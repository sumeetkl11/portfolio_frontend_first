import { useEffect, useState } from "react";
import { Terminal, Shield } from "lucide-react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState("");

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);

      // Simple active section highlights
      const sections = ["projects", "experience", "contact"];
      const scrollPos = window.scrollY + 120;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav
      id="navbar"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#131314]/80 backdrop-blur-md border-b border-white/10 py-3 shadow-lg"
          : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-[1200px] mx-auto px-6 flex justify-between items-center">
        {/* Brand Logo */}
        <div
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="flex items-center gap-2 cursor-pointer group"
        >
          <div className="p-1.5 rounded bg-blue-500/10 border border-blue-500/20 group-hover:border-blue-500/50 transition-all duration-300">
            <Terminal className="w-5 h-5 text-blue-400" />
          </div>
          <span className="font-sans font-bold tracking-tighter text-xl text-white group-hover:text-blue-300 transition-colors">
            The Digital Nexus
          </span>
        </div>

        {/* Links */}
        <div className="hidden md:flex items-center gap-8">
          {["projects", "experience", "contact"].map((sec) => (
            <button
              key={sec}
              onClick={() => scrollTo(sec)}
              className={`font-sans text-sm capitalize font-medium transition-all duration-200 cursor-pointer ${
                activeSection === sec
                  ? "text-blue-400 font-semibold"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              {sec}
            </button>
          ))}
        </div>

        {/* Action Button */}
        <div className="flex items-center gap-3">
          <div className="hidden lg:flex items-center gap-1.5 text-xs text-green-400 bg-green-500/5 border border-green-500/10 px-2.5 py-1 rounded">
            <Shield className="w-3.5 h-3.5" />
            <span>Secure Server Proxy v1.0</span>
          </div>

          <button
            onClick={() => scrollTo("contact")}
            className="px-5 py-2 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white text-xs font-semibold rounded font-mono uppercase tracking-wide hover:shadow-[0_0_15px_rgba(59,130,246,0.4)] transition-all duration-300 cursor-pointer active:scale-95"
          >
            Hire Me
          </button>
        </div>
      </div>
    </nav>
  );
}
