import { Navbar } from '@/components/navbar'
import { Hero } from '@/components/hero'
import { Projects } from '@/components/projects'
import { Timeline } from '@/components/timeline'
import { Contact } from '@/components/contact'
import { SceneWrapper } from '@/components/scene-wrapper'

export default function Page() {
  return (
    <>
      <SceneWrapper />
      <Navbar />
      <main>
        <Hero />
        <Projects />
        <Timeline />
        <Contact />
      </main>
    </>
  )
}
