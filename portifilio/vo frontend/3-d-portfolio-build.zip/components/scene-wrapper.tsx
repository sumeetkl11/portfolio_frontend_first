'use client'

import dynamic from 'next/dynamic'

// Load the WebGL scene client-side only, with a static gradient while it loads
const Scene = dynamic(
  () => import('@/components/scene').then((mod) => mod.Scene),
  {
    ssr: false,
    loading: () => (
      <div
        aria-hidden="true"
        className="fixed inset-0 -z-10 bg-[radial-gradient(ellipse_at_center,oklch(0.2_0.04_280)_0%,var(--background)_70%)]"
      />
    ),
  },
)

export function SceneWrapper() {
  return <Scene />
}
