'use client'

import { motion } from 'framer-motion'

const entries = [
  {
    period: '2024 — Present',
    title: 'Freelance Full Stack Developer',
    org: 'Remote',
    description:
      'Building scalable PERN-stack web applications for clients — from database schema design to production deployment.',
  },
  {
    period: '2024',
    title: 'Tastebuds — AI Initiative',
    org: 'Personal Project',
    description:
      'Led the design and development of an AI-powered social dining platform, integrating recommendation models with a real-time backend.',
  },
  {
    period: '2022 — Present',
    title: 'B.Sc. Computer Science',
    org: 'DUET — Dawood University of Engineering & Technology',
    description:
      'Focusing on software engineering, databases, and distributed systems while shipping side projects along the way.',
  },
]

export function Timeline() {
  return (
    <section id="experience" className="px-6 py-24 md:px-12">
      <div className="mx-auto max-w-3xl">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6 }}
        >
          <p className="mb-2 font-mono text-sm text-primary">
            {'// 02. The Journey'}
          </p>
          <h2 className="text-balance text-3xl font-bold tracking-tight sm:text-4xl">
            Experience Path
          </h2>
        </motion.div>

        <ol className="relative mt-12 border-l border-border pl-8">
          {entries.map((entry, i) => (
            <motion.li
              key={entry.title}
              initial={{ opacity: 0, x: -16 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="relative pb-12 last:pb-0"
            >
              {/* Glowing node */}
              <span
                aria-hidden="true"
                className="absolute -left-[2.32rem] top-1.5 size-3 rounded-full bg-accent shadow-[0_0_12px_var(--glow)]"
              />
              <p className="font-mono text-xs text-primary">{entry.period}</p>
              <h3 className="mt-1 text-lg font-semibold text-foreground">
                {entry.title}
              </h3>
              <p className="text-sm text-accent">{entry.org}</p>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {entry.description}
              </p>
            </motion.li>
          ))}
        </ol>
      </div>
    </section>
  )
}
