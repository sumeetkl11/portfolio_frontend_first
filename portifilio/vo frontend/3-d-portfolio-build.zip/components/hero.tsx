'use client'

import { motion, useReducedMotion } from 'framer-motion'
import Image from 'next/image'
import { ChevronDown } from 'lucide-react'

export function Hero() {
  const reducedMotion = useReducedMotion()

  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center px-6 pt-24 md:px-12"
    >
      <div className="mx-auto grid w-full max-w-6xl items-center gap-10 md:grid-cols-2">
        {/* Text — left column */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: 'easeOut' }}
          className="order-2 md:order-1"
        >
          <p className="mb-4 font-mono text-sm text-primary">
            {'// The Digital Nexus'}
          </p>
          <h1 className="text-balance text-4xl font-bold leading-tight tracking-tight sm:text-5xl lg:text-6xl">
            Hi, I&apos;m{' '}
            <span className="text-primary">Sumeet Kanhiya</span>.
          </h1>
          <p className="mt-5 max-w-md text-pretty text-lg leading-relaxed text-muted-foreground">
            Full Stack Developer specializing in the{' '}
            <span className="font-semibold text-foreground">PERN stack</span>{' '}
            and scalable web architectures.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#projects"
              className="rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-shadow hover:shadow-[0_0_24px_var(--glow)]"
            >
              View Projects
            </a>
            <a
              href="#contact"
              className="glass rounded-xl px-6 py-3 text-sm font-semibold text-foreground transition-colors hover:border-accent hover:text-accent"
            >
              Get in Touch
            </a>
          </div>
        </motion.div>

        {/* Image — right column, floating in zero gravity */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: 'easeOut', delay: 0.2 }}
          className="order-1 flex justify-center md:order-2"
        >
          <motion.div
            animate={reducedMotion ? undefined : { y: [0, -14, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
            className="neon-portrait relative"
          >
            <Image
              src="/sumeet-profile.png"
              alt="Sumeet Kanhiya wearing sunglasses and a white shirt"
              width={420}
              height={540}
              priority
              className="h-auto w-64 sm:w-80 lg:w-[26rem]"
            />
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute inset-x-0 bottom-8 flex flex-col items-center gap-1 text-muted-foreground">
        <span className="font-mono text-xs">Scroll to Explore</span>
        <ChevronDown className="animate-scroll-pulse size-5" aria-hidden="true" />
      </div>
    </section>
  )
}
