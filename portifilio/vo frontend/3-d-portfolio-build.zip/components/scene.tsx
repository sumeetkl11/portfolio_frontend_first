'use client'

import { Canvas, useFrame } from '@react-three/fiber'
import { Float, PerformanceMonitor } from '@react-three/drei'
import { Suspense, useEffect, useRef, useState } from 'react'
import * as THREE from 'three'

function TorusKnot() {
  const meshRef = useRef<THREE.Mesh>(null)
  const wireRef = useRef<THREE.Mesh>(null)

  useFrame((state, delta) => {
    const { pointer } = state
    if (meshRef.current) {
      meshRef.current.rotation.x += delta * 0.08
      meshRef.current.rotation.y += delta * 0.12
      // Gentle parallax toward the mouse with damping (lerp)
      meshRef.current.position.x = THREE.MathUtils.lerp(
        meshRef.current.position.x,
        pointer.x * 0.6,
        0.04,
      )
      meshRef.current.position.y = THREE.MathUtils.lerp(
        meshRef.current.position.y,
        pointer.y * 0.4,
        0.04,
      )
    }
    if (wireRef.current && meshRef.current) {
      wireRef.current.rotation.copy(meshRef.current.rotation)
      wireRef.current.position.copy(meshRef.current.position)
    }
  })

  return (
    <Float speed={1.2} rotationIntensity={0.2} floatIntensity={0.6}>
      <mesh ref={meshRef}>
        <torusKnotGeometry args={[1.4, 0.42, 128, 20]} />
        <meshPhysicalMaterial
          color="#1a1a2e"
          roughness={0.15}
          metalness={0.4}
          transmission={0.6}
          thickness={1.2}
          transparent
          opacity={0.9}
        />
      </mesh>
      <mesh ref={wireRef} scale={1.002}>
        <torusKnotGeometry args={[1.4, 0.42, 96, 16]} />
        <meshBasicMaterial
          color="#7c6cf5"
          wireframe
          transparent
          opacity={0.16}
        />
      </mesh>
    </Float>
  )
}

function Particles({ count = 350 }: { count?: number }) {
  const pointsRef = useRef<THREE.Points>(null)
  const positions = useRef<Float32Array | null>(null)

  if (!positions.current) {
    const arr = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 20
      arr[i * 3 + 1] = (Math.random() - 0.5) * 14
      arr[i * 3 + 2] = (Math.random() - 0.5) * 10 - 2
    }
    positions.current = arr
  }

  useFrame((state, delta) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y += delta * 0.015
      pointsRef.current.rotation.x = THREE.MathUtils.lerp(
        pointsRef.current.rotation.x,
        state.pointer.y * 0.05,
        0.02,
      )
    }
  })

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions.current, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        color="#5aa9e6"
        size={0.03}
        sizeAttenuation
        transparent
        opacity={0.55}
        depthWrite={false}
      />
    </points>
  )
}

export function Scene() {
  const [reducedMotion, setReducedMotion] = useState(false)
  const [dpr, setDpr] = useState<[number, number]>([1, 1.5])

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)')
    setReducedMotion(mq.matches)
    const onChange = (e: MediaQueryListEvent) => setReducedMotion(e.matches)
    mq.addEventListener('change', onChange)
    return () => mq.removeEventListener('change', onChange)
  }, [])

  // Respect OS reduced-motion: unmount WebGL entirely, fall back to CSS
  if (reducedMotion) {
    return (
      <div
        aria-hidden="true"
        className="fixed inset-0 -z-10 bg-[radial-gradient(ellipse_at_center,oklch(0.2_0.04_280)_0%,var(--background)_70%)]"
      />
    )
  }

  return (
    <div className="fixed inset-0 -z-10" aria-hidden="true">
      <Canvas
        dpr={dpr}
        camera={{ position: [0, 0, 6], fov: 45 }}
        gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
        fallback={
          <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_center,oklch(0.2_0.04_280)_0%,var(--background)_70%)]" />
        }
      >
        <PerformanceMonitor
          onDecline={() => setDpr([1, 1])}
          onIncline={() => setDpr([1, 1.5])}
        >
          <color attach="background" args={['#14141f']} />
          <fog attach="fog" args={['#14141f', 6, 16]} />
          <ambientLight intensity={0.4} />
          <directionalLight position={[4, 6, 4]} intensity={1.2} color="#8ec5ff" />
          <pointLight position={[-4, -2, 2]} intensity={6} color="#7c6cf5" />
          <Suspense fallback={null}>
            <TorusKnot />
            <Particles />
          </Suspense>
        </PerformanceMonitor>
      </Canvas>
    </div>
  )
}
