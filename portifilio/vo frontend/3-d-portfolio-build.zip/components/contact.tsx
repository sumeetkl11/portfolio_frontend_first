'use client'

import { motion } from 'framer-motion'
import { Mail } from 'lucide-react'
import { GithubIcon, LinkedinIcon } from '@/components/brand-icons'

const socials = [
  {
    label: 'GitHub',
    href: 'https://github.com/',
    icon: GithubIcon,
  },
  {
    label: 'LinkedIn',
    href: 'https://linkedin.com/',
    icon: LinkedinIcon,
  },
]

export function Contact() {
  return (
    <section id="contact" className="px-6 py-24 md:px-12">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-80px' }}
        transition={{ duration: 0.6 }}
        className="glass mx-auto flex max-w-3xl flex-col items-center rounded-3xl px-6 py-16 text-center"
      >
        <p className="mb-2 font-mono text-sm text-primary">
          {'// 03. Terminal Core'}
        </p>
        <h2 className="text-balance text-3xl font-bold tracking-tight sm:text-4xl">
          Let&apos;s Build Something Scalable
        </h2>
        <p className="mt-4 max-w-md text-pretty leading-relaxed text-muted-foreground">
          Open to freelance work, collaborations, and full-time opportunities.
          Drop a message and let&apos;s talk architecture.
        </p>
        <a
          href="mailto:hello@sumeetkanhiya.dev"
          className="mt-8 inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-4 text-sm font-semibold text-primary-foreground transition-shadow hover:shadow-[0_0_32px_var(--glow)]"
        >
          <Mail className="size-4" aria-hidden="true" />
          hello@sumeetkanhiya.dev
        </a>
        <div className="mt-8 flex gap-3">
          {socials.map((social) => (
            <a
              key={social.label}
              href={social.href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={social.label}
              className="glass rounded-xl p-3 text-muted-foreground transition-all hover:border-accent hover:text-accent hover:shadow-[0_0_16px_var(--glow)]"
            >
              <social.icon className="size-5" aria-hidden="true" />
            </a>
          ))}
        </div>
      </motion.div>

      <footer className="mt-16 text-center font-mono text-xs text-muted-foreground">
        <p>
          Sumeet Kanhiya — The Digital Nexus. Built with Next.js, R3F &amp;
          Tailwind.
        </p>
      </footer>
    </section>
  )
}
