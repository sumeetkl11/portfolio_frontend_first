'use client'

import Tilt from 'react-parallax-tilt'
import { motion } from 'framer-motion'
import { ArrowUpRight } from 'lucide-react'
import { GithubIcon } from '@/components/brand-icons'

const projects = [
  {
    title: 'Tastebuds',
    description:
      'An AI-powered social dining platform that matches people over shared food preferences, with real-time chat and smart restaurant recommendations.',
    stack: ['PostgreSQL', 'Express', 'React', 'Node.js', 'AI'],
    github: 'https://github.com/',
  },
  {
    title: 'SocialConnect',
    description:
      'A full-featured social network with posts, follows, notifications, and an optimized feed built on cursor-based pagination.',
    stack: ['PERN', 'Redis', 'WebSockets'],
    github: 'https://github.com/',
  },
  {
    title: 'Linkforge',
    description:
      'A blazing-fast URL shortener and link-in-bio tool with click analytics, custom domains, and QR code generation.',
    stack: ['Next.js', 'PostgreSQL', 'Edge'],
    github: 'https://github.com/',
  },
]

export function Projects() {
  return (
    <section id="projects" className="px-6 py-24 md:px-12">
      <div className="mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6 }}
        >
          <p className="mb-2 font-mono text-sm text-primary">
            {'// 01. Featured Work'}
          </p>
          <h2 className="text-balance text-3xl font-bold tracking-tight sm:text-4xl">
            Project Monoliths
          </h2>
        </motion.div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {projects.map((project, i) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, delay: i * 0.12 }}
            >
              <Tilt
                tiltMaxAngleX={6}
                tiltMaxAngleY={6}
                transitionSpeed={1500}
                scale={1.02}
                className="h-full"
              >
                <article className="glass group flex h-full flex-col rounded-2xl p-6 transition-shadow hover:shadow-[0_0_32px_oklch(0.62_0.19_292_/_25%)]">
                  <div className="flex items-start justify-between">
                    <h3 className="text-xl font-semibold text-foreground transition-colors group-hover:text-primary">
                      {project.title}
                    </h3>
                    <a
                      href={project.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`${project.title} on GitHub`}
                      className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-primary"
                    >
                      <GithubIcon className="size-5" aria-hidden="true" />
                    </a>
                  </div>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
                    {project.description}
                  </p>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {project.stack.map((tech) => (
                      <span
                        key={tech}
                        className="rounded-full border border-border bg-secondary px-3 py-1 font-mono text-xs text-primary"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-5 inline-flex items-center gap-1 text-sm font-medium text-accent transition-colors hover:text-primary"
                  >
                    View Architecture
                    <ArrowUpRight className="size-4" aria-hidden="true" />
                  </a>
                </article>
              </Tilt>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
